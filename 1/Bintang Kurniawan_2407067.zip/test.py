# Nama: Bintang Kurniawan
# NIM: 2407067
# Kelas: RPL 1 A
nama = input("nama: ")
umur = input("umur: ")
print(f"Halo {nama} umur kamu adalah {umur}")
