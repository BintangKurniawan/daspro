# Nama: Bintang Kurniawan
# NIM: 2407067
# Kelas: RPL 1 A

numbers = {10,20,20,30,40,50,50,60}
num2 = list(set(numbers))
num2.sort()
print(num2)