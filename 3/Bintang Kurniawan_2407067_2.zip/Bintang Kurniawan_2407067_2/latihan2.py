# Nama: Bintang Kurniawan
# NIM: 2407067
# Kelas: RPL 1 A


students = {
    "Alice" : "Computer Science",
    "Bob" : "Mathematics",
    "Charlie" : "Physics",
    "David" : "Computer Science",
    "Eva" : "Mathematics",
}

# jurusan = input("Masukkan jurusan: ").capitalize()

# print(jurusan)

# bnykSiswa = students.get(jurusan)

jurusan = input("Masukkan jurusan pertama: ").title()
jurusan2 = input("Masukkan jurusan kedua: ").title()
jurusan3 = input("Masukkan jurusan ketiga: ").title()

print("prodi", jurusan, "ada sebanyak", list(students.values()).count(jurusan), "orang")

print("prodi", jurusan2, "ada sebanyak", list(students.values()).count(jurusan2), "orang")

print("prodi", jurusan3, "ada sebanyak", list(students.values()).count(jurusan3), "orang")