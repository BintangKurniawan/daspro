# Nama: Bintang Kurniawan
# NIM: 2407067
# Kelas: RPL 1 A

nilai = int(input("Masukkan Nilai: "))

if nilai >= 90:
    print("Bernilai A")
elif nilai < 90 and nilai >= 80:
    print("Bernilai B")
elif nilai < 80 and nilai >= 70:
    print("Bernilai C")
else:
    print("Bernilai D")
