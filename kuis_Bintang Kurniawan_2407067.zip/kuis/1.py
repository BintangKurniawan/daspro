# Nama: Bintang Kurniawan
# NIM: 2407067
# Kelas: RPL 1 A

menit = 13
detik = 37

total = menit * 60 + detik

print(f"Hasil konversi adalah {total} detik")