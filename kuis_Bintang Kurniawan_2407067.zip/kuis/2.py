# Nama: Bintang Kurniawan
# NIM: 2407067
# Kelas: RPL 1 A

panjang = 10

lebar = 15

kedalaman = 2

volMaksimal = panjang * lebar * kedalaman

print(f"Volume maksimal dari kolam tersebut adalah {volMaksimal} meter^3")