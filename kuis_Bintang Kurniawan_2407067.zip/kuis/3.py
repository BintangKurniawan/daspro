# Nama: Bintang Kurniawan
# NIM: 2407067
# Kelas: RPL 1 A

p = 10
t = 3.5
l = 8

luas = 2 * (p*t) + 2 * (l * t)

biaya = 580000 * luas

print(f"Biaya yang harus dikeluarkan sebanyak: Rp. {biaya}")