# Nama: Bintang Kurniawan
# NIM: 2407067
# Kelas: RPL 1 A

mobil = {
    "Merk": "Honda",
    "Tipe": "HRV",
    "Tahun": 2018,
    "Warna" : "Hitam",
    "No. Polisi": "D 1234 ABC",
    "Bensin": "Pertalite",
    "Tranmisi": "Manual"
}
 
print(f"Mobil lama Pak Oki adalah:\nMerk: {mobil["Merk"]}\nTipe mobil: {mobil["Tipe"]}\nTahun keluaran: {mobil["Tahun"]}\nWarna: {mobil["Warna"]}\nNo. Polisi: {mobil["No. Polisi"]}\nBensin: {mobil["Bensin"]}\nTransmisi: {mobil["Tranmisi"]}")

print()

print("Masukkan informasi detail mobil baru")
mobil["Merk"] = input("Merk:")
mobil["Tipe"] = input("Tipe mobil:")
mobil["Tahun"] = input("Tahun Keluaran:")
mobil["Warna"] = input("Warna:")
mobil["No. Polisi"] = input("No. Polisi:")
mobil["Bensin"] = input("Bensin:")
mobil["Tranmisi"] = input("Transmisi:")

print()

print("-----------***-----------")
print(f"Mobil baru Pak Oki adalah:\nMerk: {mobil["Merk"]}\nTipe mobil: {mobil["Tipe"]}\nTahun keluaran: {mobil["Tahun"]}\nWarna: {mobil["Warna"]}\nNo. Polisi: {mobil["No. Polisi"]}\nBensin: {mobil["Bensin"]}\nTransmisi: {mobil["Tranmisi"]}")
print("-----------***-----------")