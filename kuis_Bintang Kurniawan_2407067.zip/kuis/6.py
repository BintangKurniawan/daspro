# Nama: Bintang Kurniawan
# NIM: 2407067
# Kelas: RPL 1 A

daftarNilai = [78, 90, 56, 98, 65, 38, 42, 74, 89, 90]



absen = int(input("Masukkan nomor urut siswa:"))
print(daftarNilai[absen-1])